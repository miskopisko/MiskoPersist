using MPersist.Core;
using MPersist.Core.Message.Request;

namespace $rootnamespace$.Requests
{
    public class $safeitemname$ : RequestMessage
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Parameters

        

        #endregion
        
        #region Constructor
        
        public $safeitemname$()
        {
        }
        
        #endregion
    }
}