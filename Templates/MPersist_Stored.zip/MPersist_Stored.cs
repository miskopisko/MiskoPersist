using System;
using MPersist.Core;
using MPersist.Core.Attributes;
using MPersist.Core.Data;
using MPersist.Core.Enums;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractStoredData
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Fields

	

        #endregion

        #region Stored Properties

	

        #endregion
        
        #region Other Properties
	
	
	
        #endregion

        #region Constructors

	public $safeitemname$()
	{
	}

	public $safeitemname$(Session session, Persistence persistence) : base(session, persistence)
	{
        }

        #endregion
        
        #region Override Methods
	
	public override AbstractStoredData Create(Session session)
	{
	    PreSave(session, UpdateMode.Insert);
	    Persistence.ExecuteInsert(session, this, typeof($safeitemname$));
	    PostSave(session, UpdateMode.Insert);
	    return this;
	}

	public override AbstractStoredData Store(Session session)
	{
	    PreSave(session, UpdateMode.Update);
	    Persistence.ExecuteUpdate(session, this, typeof($safeitemname$));
	    PostSave(session, UpdateMode.Update);
	    return this;
	}

	public override AbstractStoredData Remove(Session session)
	{
	    Persistence.ExecuteDelete(session, this, typeof($safeitemname$));
	    PostSave(session, UpdateMode.Delete);
	    return this;
	}

	public void PreSave(Session session, UpdateMode mode)
	{
	}

	public void PostSave(Session session, UpdateMode mode)
	{
        }
	
        #endregion

        #region Private Methods

	

        #endregion

        #region Public Methods

	

        #endregion
    }
}
