using System;
using MPersist.Core;
using MPersist.Core.Data;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractViewedDataList<$basename$>
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Fields

	

        #endregion

        #region Properties

	

        #endregion

        #region Constructors

        public $safeitemname$()
        {
        }

        #endregion

        #region Private Methods

	

        #endregion

        #region Public Methods

	

        #endregion
    }
}